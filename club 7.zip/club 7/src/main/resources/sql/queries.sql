--consulta para obtener todas las actividades

SELECT * FROM actividad;

--consulta para obtener los socios 

SELECT * FROM socio;

--consulta para obtener los entrenadores 

SELECT * FROM entrenador;

--consulta para obtener los socios que practican la actividad numero 1

SELECT * FROM socio WHERE idActividad = 1;

--consulta para obtener los entrenadores que imparten la actividad 2

SELECT * FROM entrenador WHERE idActividad = 2;